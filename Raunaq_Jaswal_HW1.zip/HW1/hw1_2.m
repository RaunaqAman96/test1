clc;
clear;

%%%%%%Part 2%%%%%%%

[myvoice,fs_myvoice]=audioread("myvoice.wav");                          %Audioread the input file
myvoice_zeromean=myvoice-mean(myvoice);                                 %Zero mean the input
myvoice_rms=rms(myvoice_zeromean);                                      %RMS of input
[noise,fs_noise]=audioread("noise.wav");                                %Audio read the noise file
noise=noise(1:length(myvoice));                                         %Truncate the noise to same length as input audio
noise_zeromean=noise-mean(noise);                                       %Zero mean the noise
noise_rms=rms(noise_zeromean);                                          %RMS of noise
scale=(10^0.25)*(noise_rms/myvoice_rms);                                %Calculate the scaling factor to make SNR = 5dB
myvoice_scaled=scale*myvoice_zeromean;                                  %Scaled Input
myvoice_scaled_rms=rms(myvoice_scaled)                                  %RMS of scaled input
myvoice_noisy=myvoice_scaled+noise_zeromean;                            %Scaled input + Noise                     
audiowrite("myvoice_noisy.wav",myvoice_noisy,fs_myvoice);


%%%%%%Part 3%%%%%%%
L=512;                                                                  %Length of Window
myvoice_down=resample(myvoice,16000,44100);                             %Resampling the input
myvoice_windowed=hamming(L).*myvoice_down(13500:13500+L-1);             %Windowing the input
myvoice_zero=cat(1,myvoice_windowed,zeros(L*3,1));                      %Padding the input
myvoice_fft=fft(myvoice_zero);                                          %FFT
fft_length=length(myvoice_fft);                                         %FFT Length
myvoice_magdb=20*log10(abs(myvoice_fft));                               %Magnitude of FFT of input
figure(1);
plot((0:fft_length/2)*16000/fft_length,myvoice_magdb(1:(fft_length/2)+1));  %Plotting the magnitude spectra
grid on;
xlabel('Frequency(Hz)');
ylabel('Amplitude (dB)');


%%%%%Part 4%%%%%%%

[myvoice_stft,freq,samples]=spectrogram(myvoice_down,hamming(L),256,'twosided','yaxis');        %STFT the downsampled input with Hamming window of length=512 and hop size=256
figure(2);
spectrogram(myvoice_down,hamming(L),256,8000,16000,'onesided','yaxis');                         %Plot the magnitude spectrogram

%%%%%Part 5%%%%%%


myvoice_mag=abs(myvoice_stft);                                          %Magnitude of STFT results
myvoice_phase = angle(myvoice_stft);                                    %Argument of STFT results
a = round(300*length(freq)/16000);                                      %Index where frequency = 300
b = round(3400*length(freq)/16000);                                     %Index where frequency =3400        
c=cat(1,zeros(a-1,length(samples)),myvoice_mag(a:b,1:length(samples)),zeros(length(freq)-b,length(samples)));   %Zeroing magnitudes at all other frequencies
[x,y]=pol2cart(myvoice_phase,c);                                                                
z=x+i*y;                                                                %Modified spectrogram
z1=istft(z,'Window',hamming(L),'OverlapLength',256,'Method','ola');     %Result from overlap-add
myvoice_telephone=abs(z1);                                              %Getting the modified audio
audiowrite('myvoice_telephone.wav',myvoice_telephone,16000);
[x,y]=pol2cart(zeros(length(freq),length(samples)),c);                  %Making the phase zero 
z=x+i*y;
z1=istft(z,'Window',hamming(L),'OverlapLength',256,'Method','ola');
myvoice_telephone=abs(z1);                                              %Getting the modified audio
audiowrite('myvoice_telephone_zerophase.wav',myvoice_telephone,16000);

