clear;
clc;

%%%%Part 1%%%%
fs=44100;                                               %Sample Frequency
t=0:1/fs:3;                                            
f = [110;220;440;880;1760;3520];                                    %Frequency of the sinusoids
x=0.25*sin(2*pi*f*t);                                               %Sinusoids
x_complex=x(1,:)+x(2,:)+x(3,:)+x(4,:)+x(5,:)+x(6,:);                %Complex Tone     
audiowrite("complextone.wav",x_complex,fs);             

%%%%Part 2%%%%
midi_number=69 + 12*log2(f/440);                                    %Calculating MIDI number for corresponding frequencies
mean=81;        
sd=12;
gain=(1/sqrt(2*pi*sd^2))*exp(-((midi_number-mean).^2)/(2*sd^2));    %Gaussian function with mean=81 and sd=12
x_gauss=gain.*x;                                                    %Gaussian function shaping the amplitude
x_complexgauss=x_gauss(1,:)+x_gauss(2,:)+x_gauss(3,:)+x_gauss(4,:)+x_gauss(5,:)+x_gauss(6,:);   %Complex Gaussian tone
audiowrite("complextone_Gaussian.wav",x_complexgauss,fs);

%%%%Part 3%%%%

t1=0:1/fs:0.5;
t2=0:1/fs:1;
x_tone = cat(2,x_complexgauss(1:length(t1)),zeros(1,length(t1)));   %Complex tone of length 0.5 sec and 0.5 sec of silence
x1=x_tone;                                                          %Complex tone with initial MIDI values
for count=1:11                                                      %Loop to generate 12 tones
midi_number=midi_number+1;                                          %Updating MIDI number
f=440*(2.^((midi_number-69)/12));                                   %Calculating frequency corresponing to the updated MIDI number 
x=0.25*sin(2*pi*f*t1);                                              %generation of new tone
gain=(1/sqrt(2*pi*sd^2))*exp(-((midi_number-mean).^2)/(2*sd^2));    
x_gauss=gain.*x;                                                    %Gaussian function shaping the amplitude
x_complexgauss=x_gauss(1,:)+x_gauss(2,:)+x_gauss(3,:)+x_gauss(4,:)+x_gauss(5,:)+x_gauss(6,:);   %Complex Gaussian tone 
x_tone = cat(2,x_complexgauss,zeros(1,length(t1)));                 %New Complex tone
hop=length(t2)*count;                                               %Hop Index
x1= cat(2,x1(1:hop),x_tone);                                        %Adding to exisitng tones                                       
end
shepard_tone=cat(2,x1,x1,x1,x1,x1);                                 %Copying it 5 times
audiowrite("ShepardTone.wav",shepard_tone,fs);